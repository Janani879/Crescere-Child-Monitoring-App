package com.example.childmonitoringel

data class User(val name:String,val mail:String,val password:String,val weight:String,val age:String)
{

}