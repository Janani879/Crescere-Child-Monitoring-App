package com.example.childmonitoringel


data class HeightResponse(
    val height: Double
)
