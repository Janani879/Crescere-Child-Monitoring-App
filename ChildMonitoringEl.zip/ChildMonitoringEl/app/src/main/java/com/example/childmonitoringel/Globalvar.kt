package com.example.childmonitoringel

import org.jetbrains.annotations.Nullable

object Globalvar {
    var mailId: String? = null
    var name:String?=null
    var weight:String?=null
    var age:String?=null
    var password:String?=null
    var height:String?=null


}
